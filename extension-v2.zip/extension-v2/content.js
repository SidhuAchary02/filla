/**
 * content.js  v4 — Filla Autofill Engine
 *
 * FIXES vs v3:
 *  1. detectSection() now recognises "Experience Details" and "Education Details"
 *     (the exact headings on this form), not just "Work Experience N"
 *  2. "Location" field INSIDE work/edu sections → resolved from job/edu data,
 *     NOT from user's home city (separate key: work_location_val)
 *  3. Nationality select → resolved to "India" (loc.country)
 *  4. Experience (in years) → number input → fills 0
 *  5. Expected Salary → number input → fills raw number 1500000
 *  6. Official Notice Period (in days) → number input → fills 0
 *  7. "Date of Joining" / "Date of Relieving" → MM/YYYY text inputs
 *  8. "Start of Course" / "End of Course" → YYYY text inputs
 *  9. "Course" → maps to degree value
 * 10. "Branch/ Specialization" → maps to field_of_study
 * 11. "University/ College" → maps to school
 * 12. "Github/Portfolio Link" single field → filled with both URLs
 */

(function () {
  "use strict";

  let _logLines = [];
  let _complexPromptSeen = false;

  if (window.__fillaV4Loaded) return;
  window.__fillaV4Loaded = true;

  const FM = window.FillaFieldMapper;

  function safeRuntimeUrl(path) {
    try {
      if (!chrome?.runtime?.id || typeof chrome.runtime.getURL !== "function") return "";
      return chrome.runtime.getURL(path);
    } catch (_) {
      return "";
    }
  }

  async function openExtensionPopupPage() {
    const popupUrl = safeRuntimeUrl("popup.html");
    if (!popupUrl) return;

    const resp = await sendMessageAsync({ type: "FILLA_OPEN_POPUP_PAGE", url: popupUrl });
    if (!resp?.success) {
      // Fallback: open directly from page context if background route fails.
      window.open(popupUrl, "_blank", "noopener,noreferrer");
    }
  }

  /* ═══════════════════════════════════════════════════════════════
     FLOATING UI
  ═══════════════════════════════════════════════════════════════ */

  function createFloatingLogo() {
    // keep existing instance to avoid click misses from frequent DOM re-creation
    const existing = document.getElementById("filla-floating-logo");
    if (existing) return;
    // remove legacy complex loader if present, so only one icon is visible
    document.getElementById("filla-complex-loader")?.remove();

    const button = document.createElement("button");
    button.id = "filla-floating-logo";
    button.type = "button";
    button.setAttribute("aria-label", "Open Filla popup");

    const logo = document.createElement("img");
    const primaryLogoSrc = safeRuntimeUrl("logo-2.png");
    const fallbackLogoSrc = safeRuntimeUrl("logo.png");
    if (!primaryLogoSrc && !fallbackLogoSrc) return;
    logo.src = primaryLogoSrc; // packaged extension logo
    logo.onerror = () => {
      if (fallbackLogoSrc && logo.src !== fallbackLogoSrc) {
        logo.src = fallbackLogoSrc;
        return;
      }
      console.warn("[Filla] Logo failed to load from extension package");
    };

    Object.assign(button.style, {
      position: "fixed",
      top: "16px",
      right: "0px", // attached to right edge
      width: "60px", // small size
      height: "50px",
      zIndex: "2147483647",
      cursor: "pointer",
      padding: "6px",
      background: "#fff",
      border: "none",
      borderRadius: "8px 0 0 8px", // rounded only on left
      boxShadow: "0 4px 12px rgba(95,36,15,0.35)",
      display: "flex",
      alignItems: "center",
      justifyContent: "center",
    });

    Object.assign(logo.style, {
      width: "100%",
      height: "100%",
      objectFit: "contain",
      pointerEvents: "none",
    });

    button.onclick = () => {
      console.log("Filla icon clicked");
      openExtensionPopupPage();
    };

    button.appendChild(logo);
    document.body.appendChild(button);
  }

  function removeFloatingLogo() {
    document.getElementById("filla-floating-logo")?.remove();
  }

  function getLikelyFillableFields() {
    return Array.from(document.querySelectorAll(
      'input:not([type="hidden"]):not([type="submit"]):not([type="button"]):not([type="image"]):not([type="reset"]), textarea, select, [role="combobox"], [contenteditable="true"]'
    )).filter((el) => {
      if (!(el instanceof HTMLElement)) return false;
      const isInput = el.tagName.toLowerCase() === "input";
      if (isInput) {
        const t = (el.getAttribute("type") || "text").toLowerCase();
        if (["radio", "checkbox"].includes(t)) return false;
      }
      if (el.hasAttribute("disabled") || el.getAttribute("aria-hidden") === "true") return false;
      const rect = el.getBoundingClientRect();
      return rect.width > 0 && rect.height > 0;
    });
  }

  function isValidAutofillPage() {
    const fillable = getLikelyFillableFields();
    if (fillable.length >= 3) return true;

    const pageText = FM.normalize([
      document.title || "",
      location.pathname || "",
      document.body?.innerText?.slice(0, 4000) || "",
    ].join(" "));
    const hostPath = FM.normalize(`${location.hostname} ${location.pathname}`);
    const hasApplyIntent = /(apply|application|job|career|resume|cover letter|workday|greenhouse|lever|ashby|smartrecruiters)/.test(pageText);
    const jobPlatformPath = /(workday|greenhouse|lever|ashby|smartrecruiters|jobs|careers)/.test(hostPath);
    return (fillable.length >= 1 && hasApplyIntent) || (fillable.length >= 1 && jobPlatformPath);
  }

  function applyFloatingLogoForPage() {
    // Always show the floating logo as requested.
    createFloatingLogo();
  }

  function setupFloatingLogoWatcher() {
    const refresh = () => {
      applyFloatingLogoForPage();
    };

    refresh();
    let debounce = null;
    const observer = new MutationObserver(() => {
      clearTimeout(debounce);
      debounce = setTimeout(refresh, 500);
    });
    observer.observe(document.documentElement, { childList: true, subtree: true });
    setTimeout(() => observer.disconnect(), 120000);
  }

  function showComplexLoader() {
    // Reuse the same floating logo UI to avoid duplicate icons.
    createFloatingLogo();
  }

  function hideComplexLoader() {
    document.getElementById("filla-complex-loader")?.remove();
  }

  function ensureUnknownFieldAIBtn(el, fingerprint = "") {
    return;
  }

  function injectUnknownAIButtons(userData) {
    return;
  }

  function getBox() {
    let b = document.getElementById("filla-ui");
    if (!b) { b = document.createElement("div"); b.id = "filla-ui"; document.body.appendChild(b); }
    return b;
  }
  function uiLog(line) {
    _logLines.push(line);
    if (_logLines.length > 14) _logLines.shift();
    const el = document.getElementById("filla-log");
    if (el) el.innerHTML = _logLines.join("<br>");
  }
  function showUI(status, progress = "") {
    const box = getBox();
    const headerLogoSrc = safeRuntimeUrl("logo-2.png");
    box.style.cssText = "";
    box.innerHTML = `
      <div id="filla-header">
        <img src="${headerLogoSrc}" alt="Filla Logo" id="filla-logo">
        <div><div id="filla-title">Filla Autofill</div>
             <div id="filla-status">${status}</div></div>
      </div>
      <div id="filla-progress">${progress}</div>
      <div id="filla-log"></div>`;
    if (_logLines.length) document.getElementById("filla-log").innerHTML = _logLines.join("<br>");
  }
  /* ═══════════════════════════════════════════════════════════════
     UTILITIES
  ═══════════════════════════════════════════════════════════════ */
  const delay = ms => new Promise(r => setTimeout(r, ms));
  const scroll = el => el.scrollIntoView({ behavior: "smooth", block: "center" });

  function sendMessageAsync(message) {
    return new Promise((resolve) => {
      try {
        chrome.runtime.sendMessage(message, (resp) => {
          if (chrome.runtime.lastError) {
            resolve({ success: false, error: chrome.runtime.lastError.message });
            return;
          }
          resolve(resp || { success: false, error: "No response from background" });
        });
      } catch (err) {
        resolve({ success: false, error: err?.message || "Message send failed" });
      }
    });
  }

  function parseFilename(contentDisposition, fallbackUrl, contentType) {
    const cd = String(contentDisposition || "");
    const m = cd.match(/filename\*=UTF-8''([^;]+)|filename="?([^";]+)"?/i);
    let name = decodeURIComponent((m?.[1] || m?.[2] || "").trim());

    if (!name) {
      try {
        const u = new URL(String(fallbackUrl || ""));
        name = (u.pathname.split("/").pop() || "").trim();
      } catch (_) {
        name = "";
      }
    }

    if (!name || !name.includes(".")) {
      const t = String(contentType || "").toLowerCase();
      const ext = t.includes("pdf") ? "pdf"
        : t.includes("msword") ? "doc"
          : t.includes("wordprocessingml") ? "docx"
            : t.includes("rtf") ? "rtf"
              : t.includes("opendocument") ? "odt"
                : "pdf";
      name = `resume.${ext}`;
    }
    return name;
  }

  function inferResumeMimeType(fileName, contentType) {
    const ct = String(contentType || "").toLowerCase().trim();
    if (ct && ct !== "application/octet-stream") return ct;

    const name = String(fileName || "").toLowerCase();
    if (name.endsWith(".pdf")) return "application/pdf";
    if (name.endsWith(".doc")) return "application/msword";
    if (name.endsWith(".docx")) {
      return "application/vnd.openxmlformats-officedocument.wordprocessingml.document";
    }
    return "application/pdf";
  }

  function base64ToFile(base64, contentType, fileName) {
    const binary = atob(base64);
    const len = binary.length;
    const bytes = new Uint8Array(len);
    for (let i = 0; i < len; i++) bytes[i] = binary.charCodeAt(i);
    const mime = inferResumeMimeType(fileName, contentType);
    return new File([bytes], fileName, { type: mime });
  }

  function hideUI(afterMs = 2200) {
    setTimeout(() => {
      const box = document.getElementById("filla-ui");
      if (box) box.remove();
    }, afterMs);
  }

  function clearResumeErrorText(root) {
    if (!root) return;
    const nodes = root.querySelectorAll("div,span,p,small,li");
    nodes.forEach((n) => {
      const txt = String(n.textContent || "").toLowerCase().trim();
      if (txt.startsWith("file format not supported")) {
        n.style.display = "none";
      }
    });
  }

  function highlight(el) {
    const was = el.style.outline;
    el.style.outline = "2.5px solid #da5a2a";
    el.style.borderRadius = "3px";
    setTimeout(() => { el.style.outline = was; }, 700);
  }

  // React / Vue / Angular compatible event dispatch
  function fire(el) {
    try {
      const proto = Object.getPrototypeOf(el);
      const setter = Object.getOwnPropertyDescriptor(proto, "value")?.set;
      if (setter) setter.call(el, el.value);
    } catch (_) { }
    el.dispatchEvent(new Event("input", { bubbles: true }));
    el.dispatchEvent(new Event("change", { bubbles: true }));
    el.dispatchEvent(new Event("blur", { bubbles: true }));
  }

  /* ═══════════════════════════════════════════════════════════════
     SECTION DETECTOR
     Walks up the DOM from the element, reads block heading text,
     and returns { section: "work"|"education"|"", index: 0|1|... }

     Handles BOTH naming conventions seen in the wild:
       • "Work Experience 1 / 2 …"   (Greenhouse, Lever)
       • "Experience Details"         (this form — no number)
       • "Education Details"          (this form)
       • "Education 1 / 2 …"
  ═══════════════════════════════════════════════════════════════ */
  function detectSection(el) {
    let node = el.parentElement;
    let depth = 0;

    while (node && depth < 15) {
      // Only look at heading-like elements or reasonably small containers
      const headings = node.querySelectorAll
        ? Array.from(node.querySelectorAll("h1,h2,h3,h4,h5,legend,label,p,span,div"))
          .filter(h => {
            const t = (h.innerText || h.textContent || "").trim();
            return t.length > 0 && t.length < 80 && !h.querySelector("input,select,textarea");
          })
        : [];

      for (const h of headings) {
        const t = FM.normalize(h.innerText || h.textContent || "");

        // Work section — numbered: "work experience 2"
        const wn = t.match(/work experience\s*(\d+)/);
        if (wn) return { section: "work", index: parseInt(wn[1]) - 1 };

        // Education — numbered
        const en = t.match(/education\s*(\d+)/);
        if (en) return { section: "education", index: parseInt(en[1]) - 1 };

        // Work section — unnumbered: "experience details" / "work experience"
        if (t.includes("experience detail") || t.includes("work experience") || t.includes("employment detail")) {
          return { section: "work", index: 0 };
        }
        if (t.includes("education detail") || t === "education" || t.includes("academic detail")) {
          return { section: "education", index: 0 };
        }
      }

      node = node.parentElement;
      depth++;
    }

    return { section: "", index: 0 };
  }

  /* ═══════════════════════════════════════════════════════════════
     DEGREE NORMALISER
     Maps profile degree strings → synonyms for select matching
  ═══════════════════════════════════════════════════════════════ */
  const DEGREE_ALIASES = {
    "b.tech": ["bachelor", "b.tech", "btech", "b.e", "be ", "engineering", "b.sc", "bsc", "b tech"],
    "m.tech": ["master", "m.tech", "mtech", "m.e", "me "],
    "mba": ["mba", "master of business"],
    "phd": ["phd", "doctorate", "ph.d"],
    "diploma": ["diploma"],
    "10th": ["10th", "ssc", "secondary"],
    "12th": ["12th", "hsc", "higher secondary", "intermediate"],
  };
  function degreeSynonyms(degree) {
    const d = FM.normalize(degree);
    for (const [key, syns] of Object.entries(DEGREE_ALIASES)) {
      if (d.includes(key) || syns.some(s => d.includes(s))) return syns;
    }
    return [d];
  }

  /* ═══════════════════════════════════════════════════════════════
     FILL: TEXT / EMAIL / NUMBER / TEL / URL
  ═══════════════════════════════════════════════════════════════ */
  function fillText(el, value) {
    const type = (el.getAttribute("type") || "text").toLowerCase();
    let nextValue = value;

    if (type === "url") {
      const raw = String(value || "").trim();
      const firstUrl = raw.match(/https?:\/\/[^\s|,]+/i)?.[0] || "";
      nextValue = firstUrl || raw;
    }

    el.focus();
    if (type === "number") {
      const num = Number(String(nextValue).replace(/[^0-9.]/g, ""));
      if (isNaN(num)) return;
      el.value = num;
    } else {
      el.value = String(nextValue);
    }
    fire(el);
    uiLog(`✅ "${el.name || el.id || el.placeholder || "??"}" = "${el.value}"`);
  }

  /* ═══════════════════════════════════════════════════════════════
     FILL: DATE TEXT INPUT
     Detects format from placeholder and fills accordingly.
  ═══════════════════════════════════════════════════════════════ */
  function fillDate(el, isoDateStr, forceFormat) {
    if (!isoDateStr) return;
    const type = (el.getAttribute("type") || "text").toLowerCase();
    const ph = FM.normalize(el.placeholder || "");

    if (type === "date") { el.value = isoDateStr.slice(0, 10); fire(el); return; }
    if (type === "month") { el.value = isoDateStr.slice(0, 7); fire(el); return; }

    // Text input — detect format
    let formatted;
    if (forceFormat === "YYYY" || (ph.includes("yyyy") && !ph.includes("mm"))) {
      formatted = FM.toYYYY(isoDateStr);
    } else if (forceFormat === "DD/MM/YYYY" || ph.includes("dd/mm/yyyy")) {
      formatted = FM.toDDMMYYYY(isoDateStr);
    } else if (forceFormat === "MM/DD/YYYY" || ph.includes("mm/dd/yyyy")) {
      const d = new Date(isoDateStr);
      const dd = String(d.getDate()).padStart(2, "0");
      const mm = String(d.getMonth() + 1).padStart(2, "0");
      formatted = `${mm}/${dd}/${d.getFullYear()}`;
    } else if (forceFormat === "MM/YYYY" || ph.includes("mm/yyyy") || ph.includes("mm yyyy")) {
      formatted = FM.toMMYYYY(isoDateStr);
    } else if (ph.includes("yyyy")) {
      formatted = FM.toYYYY(isoDateStr);
    } else {
      formatted = FM.toMMYYYY(isoDateStr); // default
    }

    fillText(el, formatted);
  }

  function detectDateFormatFromField(el, key, fingerprint = "") {
    const parts = [
      el?.placeholder || "",
      el?.getAttribute?.("aria-label") || "",
      el?.getAttribute?.("name") || "",
      el?.getAttribute?.("id") || "",
      fingerprint || "",
      el?.closest?.("label,div,section,fieldset")?.innerText || "",
    ];
    const meta = FM.normalize(parts.join(" "));

    if (meta.includes("mm/dd/yyyy") || meta.includes("mm-dd-yyyy") || meta.includes("mm dd yyyy")) {
      return "MM/DD/YYYY";
    }
    if (meta.includes("dd/mm/yyyy") || meta.includes("dd-mm-yyyy") || meta.includes("dd mm yyyy")) {
      return "DD/MM/YYYY";
    }
    if (meta.includes("mm/yyyy") || meta.includes("mm yyyy")) return "MM/YYYY";
    if (meta.includes("yyyy") && !meta.includes("mm")) return "YYYY";

    if (key === "birthday") return "DD/MM/YYYY";
    return null;
  }

  /* ═══════════════════════════════════════════════════════════════
     FILL: TEXTAREA
  ═══════════════════════════════════════════════════════════════ */
  function fillTextarea(el, value) {
    el.focus();
    el.value = String(value);
    fire(el);
    uiLog(`✅ textarea "${el.name || el.id}"`);
  }

  /* ═══════════════════════════════════════════════════════════════
     FILL: NATIVE <select>
  ═══════════════════════════════════════════════════════════════ */
  function fillSelect(el, value, key) {
    let rawValue = String(value);
    if (key === "nationality" || key === "country") {
      const n = FM.normalize(rawValue);
      if (n === "indian") rawValue = "India";
    }

    const target = FM.normalize(rawValue);
    const synonyms = (key === "degree" || key === "course") ? degreeSynonyms(value) : [target];

    const isCountryLike = key === "nationality" || key === "country";
    const isPhoneCodeLike = key === "phone_country_code";

    function hasWholeWord(text, word) {
      const t = String(text || "");
      const w = String(word || "").trim();
      if (!t || !w) return false;
      const esc = w.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
      return new RegExp(`(^|\\b)${esc}(\\b|$)`).test(t);
    }

    function preferredDialForCountry(t) {
      const n = FM.normalize(t);
      if (n === "india" || n === "indian") return "+91";
      return "";
    }

    const preferredDial = preferredDialForCountry(rawValue);
    const hasDialOptions = Array.from(el.options).some(opt => /\+\d{1,4}/.test(opt.text || ""));

    if (isCountryLike && preferredDial && hasDialOptions) {
      let firstDialMatch = null;
      for (const opt of el.options) {
        const txt = FM.normalize(opt.text || "");
        const hasIndiaToken = txt.includes("india") || txt.includes("indian");
        if (hasIndiaToken && txt.includes(preferredDial.replace("+", ""))) {
          el.selectedIndex = opt.index;
          fire(el);
          uiLog(`✅ select "${el.name || el.id}" = "${opt.text}"`);
          return true;
        }
        if (!firstDialMatch && (txt.includes(preferredDial) || txt.includes(preferredDial.replace("+", "")))) {
          firstDialMatch = opt;
        }
      }
      if (firstDialMatch) {
        el.selectedIndex = firstDialMatch.index;
        fire(el);
        uiLog(`✅ select "${el.name || el.id}" = "${firstDialMatch.text}"`);
        return true;
      }
    }

    // Country / nationality must prefer exact match to avoid false positive like:
    // "British Indian Ocean Territory" for value "Indian".
    if (isCountryLike) {
      for (const opt of el.options) {
        const t = FM.normalize(opt.text);
        const v = FM.normalize(opt.value);
        if (t === target || v === target) {
          el.selectedIndex = opt.index;
          fire(el);
          uiLog(`✅ select "${el.name || el.id}" = "${opt.text}"`);
          return true;
        }
      }
    }

    if (isPhoneCodeLike) {
      for (const opt of el.options) {
        const t = FM.normalize(opt.text);
        const v = FM.normalize(opt.value);
        if (t.includes(target) || v.includes(target)) {
          el.selectedIndex = opt.index;
          fire(el);
          uiLog(`✅ select "${el.name || el.id}" = "${opt.text}"`);
          return true;
        }
      }
    }

    for (const opt of el.options) {
      const t = FM.normalize(opt.text);
      const v = FM.normalize(opt.value);

      const countryDirect = isCountryLike
        ? (t === target || v === target || hasWholeWord(t, target) || hasWholeWord(v, target))
        : false;
      const direct = countryDirect || t === target || v === target ||
        (!isCountryLike && target.length > 2 && (t.includes(target) || target.includes(t)));
      const syn = synonyms.some(s => s.length > 1 && (t.includes(s) || v.includes(s)));

      if (direct || syn) {
        el.selectedIndex = opt.index;
        fire(el);
        uiLog(`✅ select "${el.name || el.id}" = "${opt.text}"`);
        return true;
      }
    }
    uiLog(`⚠️ select no match: "${el.name || el.id}" for "${value}"`);
    return false;
  }
  async function waitForOptions(maxMs = 1500) {
    const start = Date.now();
    while (Date.now() - start < maxMs) {
      const opts = document.querySelectorAll('[role="option"],[role="menuitem"],[role="listitem"]');
      if (opts.length > 0) return opts;
      await delay(100);
    }
    return document.querySelectorAll('[role="option"],[role="menuitem"],[role="listitem"]');
  }

  /* ═══════════════════════════════════════════════════════════════
     FILL: CUSTOM ARIA DROPDOWN
  ═══════════════════════════════════════════════════════════════ */
  async function fillAriaDropdown(trigger, value, key) {
    let rawValue = String(value);
    if (key === "nationality" || key === "country") {
      const n = FM.normalize(rawValue);
      if (n === "indian") rawValue = "India";
    }

    const target = FM.normalize(rawValue);
    const synonyms = (key === "degree" || key === "course") ? degreeSynonyms(value) : [target];
    const isCountryLike = key === "nationality" || key === "country" || key === "work_auth_general";
    const isPhoneCodeLike = key === "phone_country_code";

    function hasWholeWord(text, word) {
      const t = String(text || "");
      const w = String(word || "").trim();
      if (!t || !w) return false;
      const esc = w.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
      return new RegExp(`(^|\\b)${esc}(\\b|$)`).test(t);
    }

    function findOptions() {
      return document.querySelectorAll('[role="option"],[role="menuitem"],[role="listitem"]');
    }

    function preferredDialForCountry(t) {
      const n = FM.normalize(t);
      if (n === "india" || n === "indian") return "+91";
      return "";
    }

    function pickFromOptions(options) {
      const preferredDial = preferredDialForCountry(rawValue);
      const hasDialOptions = Array.from(options).some(opt => /\+\d{1,4}/.test(opt.innerText || opt.textContent || ""));

      if (isCountryLike && preferredDial && hasDialOptions) {
        let firstDialMatch = null;
        for (const opt of options) {
          const t = FM.normalize(opt.innerText || opt.textContent || "");
          const hasIndiaToken = t.includes("india") || t.includes("indian");
          if (hasIndiaToken && t.includes(preferredDial.replace("+", ""))) {
            opt.click();
            uiLog(`✅ aria-select "${key}" = "${opt.innerText.trim()}"`);
            return true;
          }
          if (!firstDialMatch && (t.includes(preferredDial) || t.includes(preferredDial.replace("+", "")))) {
            firstDialMatch = opt;
          }
        }
        if (firstDialMatch) {
          firstDialMatch.click();
          uiLog(`✅ aria-select "${key}" = "${firstDialMatch.innerText.trim()}"`);
          return true;
        }
      }

      if (isCountryLike) {
        for (const opt of options) {
          const t = FM.normalize(opt.innerText || opt.textContent || "");
          if (t === target) {
            opt.click();
            uiLog(`✅ aria-select "${key}" = "${opt.innerText.trim()}"`);
            return true;
          }
        }
      }

      if (isPhoneCodeLike) {
        for (const opt of options) {
          const t = FM.normalize(opt.innerText || opt.textContent || "");
          if (t.includes(target)) {
            opt.click();
            uiLog(`✅ aria-select "${key}" = "${opt.innerText.trim()}"`);
            return true;
          }
        }
      }

      for (const opt of options) {
        const t = FM.normalize(opt.innerText || opt.textContent || "");
        const countryDirect = isCountryLike ? (t === target || hasWholeWord(t, target)) : false;
        const looseDirect = !isCountryLike && t.includes(target);
        if (countryDirect || looseDirect || synonyms.some(s => s.length > 1 && t.includes(s))) {
          opt.click();
          uiLog(`✅ aria-select "${key}" = "${opt.innerText.trim()}"`);
          return true;
        }
      }
      return false;
    }

    function typeIntoSearchInput() {
      const active = document.activeElement;
      const candidates = [
        active,
        ...Array.from(document.querySelectorAll('input[role="combobox"], input[aria-autocomplete="list"], input[type="search"], [role="combobox"] input')),
      ].filter(Boolean);

      for (const node of candidates) {
        if (!(node instanceof HTMLInputElement)) continue;
        const rect = node.getBoundingClientRect();
        if (rect.width === 0 || rect.height === 0) continue;
        node.focus();
        node.value = String(rawValue);
        fire(node);
        return true;
      }
      return false;
    }

    trigger.click();
    let options = await waitForOptions(1500);
    if (pickFromOptions(options)) {
      await delay(200);
      return true;
    }

    if (typeIntoSearchInput()) {
      await delay(350);
      options = findOptions();
      if (pickFromOptions(options)) {
        await delay(200);
        return true;
      }
    }

    document.body.click(); // close
    uiLog(`⚠️ aria-select no match "${key}" for "${value}"`);
    await delay(200);
    return false;
  }

  /* ═══════════════════════════════════════════════════════════════
     FILL: RADIO GROUP
  ═══════════════════════════════════════════════════════════════ */
  function fillRadio(radios, value) {
    const target = FM.normalize(String(value));
    for (const r of radios) {
      const byFor = r.id ? (document.querySelector(`label[for="${r.id}"]`)?.innerText || "") : "";
      const wrap = r.closest("label")?.innerText || "";
      // Only direct text nodes next to the radio, not all sibling content
      const directText = Array.from((r.parentElement?.childNodes || []))
        .filter(n => n !== r && n.nodeType === Node.TEXT_NODE)
        .map(n => n.textContent || "").join(" ");
      const rv = r.value || "";
      const combined = FM.normalize([byFor, wrap, directText, rv].join(" "));

      if (combined.includes(target) || (FM.normalize(rv).length > 1 && target.includes(FM.normalize(rv)))) {
        r.click();
        uiLog(`✅ radio "${r.name}" = "${value}"`);
        return true;
      }
    }
    uiLog(`⚠️ radio no match "${radios[0]?.name}" for "${value}"`);
    return false;
  }

  /* ═══════════════════════════════════════════════════════════════
     FILL: CHECKBOX
  ═══════════════════════════════════════════════════════════════ */
  function fillCheckbox(el, value) {
    const targets = String(value).split(",").map(v => FM.normalize(v.trim()));
    const elVal = FM.normalize(el.value || "");
    const lf = el.id ? FM.normalize(document.querySelector(`label[for="${el.id}"]`)?.innerText || "") : "";
    const lw = FM.normalize(el.closest("label")?.innerText || "");
    const pp = FM.normalize(el.parentElement?.innerText || "");

    const match = targets.some(t =>
      (elVal && (elVal.includes(t) || t.includes(elVal))) ||
      (lf && (lf.includes(t) || t.includes(lf))) ||
      (lw && (lw.includes(t) || t.includes(lw))) ||
      (pp && (pp.includes(t) || t.includes(pp)))
    );

    if (match && !el.checked) {
      el.checked = true;
      fire(el);
      uiLog(`✅ checkbox "${el.name || el.id}" checked`);
    }
  }

  /* ═══════════════════════════════════════════════════════════════
     VALUE NORMALISER — post-resolve per element context
  ═══════════════════════════════════════════════════════════════ */
  function normalizeValue(key, rawValue, el) {
    if (rawValue === null || rawValue === undefined) return rawValue;
    const type = (el.getAttribute("type") || "").toLowerCase();
    const ph = FM.normalize(el.placeholder || "");

    // Salary fields — number input gets raw number, text gets LPA string
    if (key === "min_salary" || key === "current_ctc") {
      const num = Number(rawValue);
      if (isNaN(num)) return String(rawValue);
      if (type === "number") return num;                      // raw: 1500000
      if (ph.includes("lpa") || ph.includes("lakhs")) return (num / 100000).toFixed(0) + " LPA";
      return num;                                            // default: raw number
    }

    // Notice period — number input gets 0 for "immediate"
    if (key === "notice_period" || key === "negotiable_np") {
      if (type === "number") return Number(rawValue) || 0;
      return String(rawValue) === "0" ? "0" : String(rawValue);
    }

    if (key === "experience" || key === "internship_exp") {
      return type === "number" ? Number(rawValue) : String(rawValue);
    }

    return rawValue;
  }

  /* ═══════════════════════════════════════════════════════════════
     IS DATE KEY?  Keys that should route to fillDate()
  ═══════════════════════════════════════════════════════════════ */
  const DATE_KEYS = new Set([
    "work_start", "work_end", "edu_start", "edu_end", "birthday", "lwd"
  ]);

  // Force format per key
  function dateFormat(key) {
    if (key === "edu_start" || key === "edu_end") return "YYYY";
    if (key === "work_start" || key === "work_end") return "MM/YYYY";
    if (key === "birthday") return null;
    if (key === "lwd") return "DD/MM/YYYY";
    return null;
  }

  function extractQuestionText(el, fingerprint = "") {
    const parts = [];
    const id = el.getAttribute("id") || "";
    if (id) {
      const forLabel = document.querySelector(`label[for="${id}"]`);
      if (forLabel?.innerText) parts.push(forLabel.innerText);
    }

    const wrapLabel = el.closest("label");
    if (wrapLabel?.innerText) parts.push(wrapLabel.innerText);

    const legend = el.closest("fieldset")?.querySelector("legend");
    if (legend?.innerText) parts.push(legend.innerText);

    const aria = el.getAttribute("aria-label") || "";
    const placeholder = el.getAttribute("placeholder") || "";
    if (aria) parts.push(aria);
    if (placeholder) parts.push(placeholder);

    const nearbyHeading = el.closest("div,section,article")?.querySelector("h1,h2,h3,h4,p,strong");
    if (nearbyHeading?.innerText) parts.push(nearbyHeading.innerText);

    if (fingerprint) parts.push(fingerprint);

    const joined = parts
      .map((p) => String(p || "").trim())
      .filter(Boolean)
      .join(" ")
      .replace(/\s+/g, " ")
      .trim();

    return joined.slice(0, 900);
  }

  function extractCompanyName() {
    const title = String(document.title || "").trim();
    const og = document.querySelector('meta[property="og:site_name"],meta[name="application-name"]')?.getAttribute("content") || "";
    const host = String(location.hostname || "")
      .replace(/^www\./, "")
      .split(".")[0]
      .replace(/[-_]/g, " ")
      .trim();

    if (og) return og;
    const titleCandidate = title.split("|")[0]?.split("-")[0]?.trim();
    if (titleCandidate && titleCandidate.length <= 80) return titleCandidate;
    return host || "this company";
  }

  function isOpenEndedTextarea(el, fingerprint = "") {
    if (el.tagName.toLowerCase() !== "textarea") return false;
    const text = FM.normalize([
      fingerprint,
      el.getAttribute("aria-label") || "",
      el.getAttribute("placeholder") || "",
      el.name || "",
      el.id || "",
      el.closest("label,fieldset,section,div")?.innerText?.slice(0, 220) || "",
    ].join(" "));

    return /(why|motivation|tell us|describe|explain|cover letter|about yourself|interested|excited|fit|join|challenge|accomplishment)/.test(text);
  }

  function shouldUseAIFallbackForUnknownField(el, fingerprint = "") {
    const tag = el.tagName.toLowerCase();
    const type = (el.getAttribute("type") || "text").toLowerCase();
    if (tag !== "textarea" && !(tag === "input" && ["text", "search"].includes(type))) {
      return false;
    }

    const text = FM.normalize([
      fingerprint,
      el.getAttribute("aria-label") || "",
      el.getAttribute("placeholder") || "",
      el.name || "",
      el.id || "",
    ].join(" "));

    return text.length > 24 && /(which|what|why|tell|describe|explain|despite|requires|statement|question|type here|\?)/.test(text);
  }

  function deriveUnknownFieldFallbackValue(el, userData, fingerprint = "") {
    const fp = FM.normalize(String(fingerprint || ""));
    const p = userData.profile || {};

    if (/(current or last company|last company|company you worked|current company)/.test(fp)) {
      const work = p.work_experience || [];
      const company = work.find((w) => w && typeof w === "object" && w.company)?.company;
      return String(company || "").trim();
    }

    if (/(desired work location|work location|timezone|time zone|physically located)/.test(fp)) {
      const loc = p.location || {};
      return [loc.city, loc.state, loc.country].filter(Boolean).join(", ");
    }

    if (/(linkedin)/.test(fp)) return String(p.links?.linkedin || "");
    if (/(github)/.test(fp)) return String(p.links?.github || "");
    return "";
  }

  async function generateAndFillOpenAnswer(el, fingerprint = "") {
    const question = extractQuestionText(el, fingerprint);
    if (!question || question.length < 6) return false;

    _complexPromptSeen = true;
    showComplexLoader();
    uiLog("🧠 Generating AI answer...");

    const companyName = extractCompanyName();
    const resp = await sendMessageAsync({
      type: "FILLA_GENERATE_ANSWER",
      question,
      companyName,
    });

    if (!resp?.success || !resp?.answer) {
      uiLog(`⚠️ AI answer failed: ${resp?.error || "unknown"}`);
      return false;
    }

    if (el.tagName.toLowerCase() === "textarea") {
      fillTextarea(el, resp.answer);
    } else {
      fillText(el, resp.answer);
    }
    uiLog("✅ AI answer inserted");
    return true;
  }

  function radioOptionText(radio) {
    const byFor = radio.id ? document.querySelector(`label[for="${radio.id}"]`)?.innerText || "" : "";
    const wrap = radio.closest("label")?.innerText || "";
    const par = radio.parentElement?.innerText || "";
    return String(byFor || wrap || par || radio.value || "").trim();
  }

  function pickRadioByLetter(radios, letter) {
    const target = String(letter || "").trim().toLowerCase();
    if (!target) return false;
    const letterPattern = new RegExp(`(^|\\s|\\()${target}(\\)|\\.|:|-|\\s)`, "i");

    for (const r of radios) {
      const txt = FM.normalize(radioOptionText(r));
      if (letterPattern.test(txt)) {
        r.click();
        uiLog(`✅ radio fallback picked option ${target.toUpperCase()}`);
        return true;
      }
    }
    return false;
  }

  function pickRadioFallbackLetter(fingerprint, userData) {
    const fp = FM.normalize(String(fingerprint || ""));
    const p = userData.profile || {};
    const workCount = Array.isArray(p.work_experience) ? p.work_experience.length : 0;
    const skillsRaw = Array.isArray(p.skills) ? p.skills : [];
    const skills = skillsRaw.map((s) => FM.normalize(typeof s === "string" ? s : (s?.name || s?.normalized || ""))).join(" ");
    const country = FM.normalize(p.location?.country || "");

    if (fp.includes("professional experience in software engineering")) {
      if (workCount <= 2) return "a";
      if (workCount <= 4) return "b";
      return "c";
    }

    if (fp.includes("generative ai") || fp.includes("llm") || fp.includes("agentic")) {
      if (/(generative ai|llm|agent|langchain|rag|openai|groq)/.test(skills)) return "c";
      return "b";
    }

    if (fp.includes("cloud") || fp.includes("gcp") || fp.includes("terraform") || fp.includes("grpc") || fp.includes("pub/sub")) {
      if (/(python|react|node|backend|fullstack|gcp|aws|terraform|grpc|rest)/.test(skills)) return "c";
      return "b";
    }

    if (fp.includes("physically located") && fp.includes("timezone")) {
      if (country.includes("united states") || country === "usa" || country.includes("canada")) return "a";
      return "b";
    }

    return "";
  }

  /* ═══════════════════════════════════════════════════════════════
     PROCESS ONE FIELD
  ═══════════════════════════════════════════════════════════════ */
  async function processField(el, userData) {
    const tag = el.tagName.toLowerCase();
    const type = (el.getAttribute("type") || "text").toLowerCase();

    if (["submit", "button", "image", "hidden", "reset", "file"].includes(type)) return;

    // Skip non-empty (except selects which often default to "Select One")
    if (tag !== "select" && el.value && el.value.trim() !== "") return;

    const fp = FM.extractFingerprint(el);
    const links = userData.profile?.links || {};

    // Hard-priority URL fields to avoid accidental mismatch from nearby labels.
    if (fp.includes("linkedin") && links.linkedin) {
      fillText(el, links.linkedin);
      return;
    }
    if (fp.includes("google scholar") && links.google_scholar) {
      fillText(el, links.google_scholar);
      return;
    }
    if (fp.includes("github") && links.github) {
      fillText(el, links.github);
      return;
    }

    const key = FM.matchKey(fp);

    if (isOpenEndedTextarea(el, fp)) {
      const filled = await generateAndFillOpenAnswer(el, fp);
      if (!filled) ensureUnknownFieldAIBtn(el, fp);
      return;
    }

    if (!key) {
      const fallbackValue = deriveUnknownFieldFallbackValue(el, userData, fp);
      if (fallbackValue) {
        fillText(el, fallbackValue);
        uiLog("✅ Filled unknown field via fallback rules");
        return;
      }

      if (shouldUseAIFallbackForUnknownField(el, fp)) {
        const filled = await generateAndFillOpenAnswer(el, fp);
        if (filled) return;
      }

      ensureUnknownFieldAIBtn(el, fp);
      console.log(`[Filla] ❓ "${fp.slice(0, 60)}"`);
      return;
    }

    // Detect section (work / education) and index
    const ctx = detectSection(el);

    function looksLikePhoneCountryControl(fingerprint, node) {
      const fpText = String(fingerprint || "");
      const direct = (fpText.includes("phone") || fpText.includes("mobile") || fpText.includes("telephone")) &&
        (fpText.includes("country code") || fpText.includes("dial code") || fpText.includes("isd") || fpText.includes("calling code") || fpText.includes("country"));
      if (direct) return true;

      const container = node?.closest?.("label,div,section,fieldset");
      const text = FM.normalize((container?.innerText || "").slice(0, 240));
      return (text.includes("phone") || text.includes("mobile") || text.includes("telephone")) &&
        (text.includes("country code") || text.includes("dial code") || text.includes("isd") || text.includes("calling code") || text.includes("country"));
    }

    // Special case: "Location" INSIDE a work/edu section → use section-specific value
    let resolvedKey = key;
    if ((key === "country" || key === "phone" || key === "phone_number_only") && looksLikePhoneCountryControl(fp, el)) {
      resolvedKey = "phone_country_code";
    }
    if ((key === "phone" || key === "name_fallback") &&
      (fp.includes("phone") || fp.includes("mobile") || fp.includes("telephone")) &&
      !(fp.includes("country code") || fp.includes("dial code") || fp.includes("isd") || fp.includes("calling code"))) {
      resolvedKey = "phone_number_only";
    }
    if (key === "name_fallback" && ctx.section === "work" && fp.includes("location")) resolvedKey = "work_location_val";
    if (key === "name_fallback" && ctx.section === "education" && fp.includes("location")) resolvedKey = "edu_location";

    let rawVal = FM.resolveValue(resolvedKey, userData, ctx);
    let value = normalizeValue(resolvedKey, rawVal, el);

    if (value === null || value === undefined || value === "") {
      ensureUnknownFieldAIBtn(el, fp);
      console.log(`[Filla] ⚠️ no value key="${resolvedKey}" ctx=`, ctx);
      return;
    }

    console.log(`[Filla] 🔍 key="${resolvedKey}" ctx=`, ctx, `val="${value}"`);
    highlight(el);
    scroll(el);

    // Route to correct filler
    if (tag === "textarea") return fillTextarea(el, value);
    if (tag === "select") return fillSelect(el, value, resolvedKey);
    if (type === "checkbox") return fillCheckbox(el, value);
    if (type === "date" || type === "month") return fillDate(el, String(rawVal));

    // Date text inputs: check by key or placeholder
    if (DATE_KEYS.has(resolvedKey)) {
      const adaptive = detectDateFormatFromField(el, resolvedKey, fp);
      return fillDate(el, String(rawVal), adaptive || dateFormat(resolvedKey));
    }

    const ph = FM.normalize(el.placeholder || "");
    if (ph.includes("mm/yyyy") || ph.includes("dd/mm/yyyy") || ph.includes("mm/dd/yyyy") || ph.includes("yyyy")) {
      const adaptive = detectDateFormatFromField(el, resolvedKey, fp);
      return fillDate(el, String(rawVal), adaptive || dateFormat(resolvedKey) || null);
    }

    fillText(el, value);
  }

  /* ═══════════════════════════════════════════════════════════════
     RADIO GROUPS
  ═══════════════════════════════════════════════════════════════ */
  function processRadioGroups(userData) {
    const groups = {};
    document.querySelectorAll('input[type="radio"]').forEach(r => {
      const n = r.name || `_id_${r.id}` || "_anon";
      (groups[n] = groups[n] || []).push(r);
    });

    for (const [, radios] of Object.entries(groups)) {
      const legendText = radios[0].closest("fieldset")?.querySelector("legend")?.innerText || "";
      const groupContainer = radios[0].closest('[role="group"], fieldset, .form-group, [class*="field"], [class*="question"], section, div');
      const containerText = FM.normalize((groupContainer?.innerText || "").slice(0, 300));
      const fp = FM.extractFingerprint(radios[0]) + " " + FM.normalize(legendText) + " " + containerText;
      const key = FM.matchKey(fp.trim());


      if (!key) {
        const letter = pickRadioFallbackLetter(fp, userData);
        if (letter) pickRadioByLetter(radios, letter);
        continue;
      }

      const ctx = detectSection(radios[0]);
      const raw = FM.resolveValue(key, userData, ctx);
      const val = normalizeValue(key, raw, radios[0]);
      if (!val && val !== 0) continue;

      fillRadio(radios, val);
    }
  }

  /* ═══════════════════════════════════════════════════════════════
     CURRENTLY WORKING HERE CHECKBOX
  ═══════════════════════════════════════════════════════════════ */
  function fillCurrentlyWorkingCheckboxes(userData) {
    const jobs = userData.profile?.work_experience || [];

    document.querySelectorAll('input[type="checkbox"]').forEach(cb => {
      const fp = FM.normalize([
        cb.name, cb.id,
        document.querySelector(`label[for="${cb.id}"]`)?.innerText || "",
        cb.closest("label")?.innerText || "",
        cb.parentElement?.innerText || "",
      ].join(" "));

      if (!fp.includes("currently") && !fp.includes("current")) return;

      const ctx = detectSection(cb);
      const job = jobs[ctx.index] ?? jobs[0] ?? {};

      if (job.is_current && !cb.checked) {
        cb.click();
        uiLog(`✅ "Currently working here" checked (job ${ctx.index})`);
      }
    });
  }

  /* ═══════════════════════════════════════════════════════════════
     ARIA / CUSTOM DROPDOWNS  (React comboboxes etc.)
  ═══════════════════════════════════════════════════════════════ */
  async function processAriaDropdowns(userData) {
    const combos = document.querySelectorAll(
      '[role="combobox"],[aria-haspopup="listbox"],[aria-haspopup="true"]'
    );

    for (const dd of combos) {
      const fp = FM.extractFingerprint(dd);
      const key = FM.matchKey(fp);
      if (!key) {
        ensureUnknownFieldAIBtn(dd, fp);
        continue;
      }

      document.body.click();
      await delay(150);

      const ctx = detectSection(dd);
      let resolvedKey = key;

      const container = dd.closest("label,div,section,fieldset");
      const nearbyText = FM.normalize((container?.innerText || "").slice(0, 320));
      const hasNearbyPhoneInput = !!container?.querySelector?.('input[type="tel"], input[name*="phone" i], input[id*="phone" i]');
      const phoneCountryByContext =
        (hasNearbyPhoneInput ||
          fp.includes("phone") || fp.includes("mobile") || fp.includes("telephone") || fp.includes("contact") ||
          nearbyText.includes("phone") || nearbyText.includes("mobile") || nearbyText.includes("telephone")) &&
        (fp.includes("country") || fp.includes("code") || fp.includes("dial") || fp.includes("isd") ||
          nearbyText.includes("country") || nearbyText.includes("code") || nearbyText.includes("dial") || nearbyText.includes("isd"));

      if (phoneCountryByContext) {
        resolvedKey = "phone_country_code";
      }

      if (key === "country") {
        const fpLower = fp;
        if ((fpLower.includes("phone") || fpLower.includes("mobile") || fpLower.includes("telephone")) &&
          (fpLower.includes("country code") || fpLower.includes("dial code") || fpLower.includes("isd") || fpLower.includes("calling code"))) {
          resolvedKey = "phone_country_code";
        }
      }

      const raw = FM.resolveValue(resolvedKey, userData, ctx);
      if (raw === null || raw === undefined || raw === "") continue;

      await fillAriaDropdown(dd, raw, resolvedKey);
    }
  }

  /* ═══════════════════════════════════════════════════════════════
     WEBSITES / SOCIAL LINKS
  ═══════════════════════════════════════════════════════════════ */
  async function fillSocialAndWebsiteLinks(userData) {
    const p = userData.profile || {};

    const allInputs = document.querySelectorAll(
      'input[type="text"],input[type="url"],input[type="search"]'
    );

    for (const inp of allInputs) {
      const fp = FM.extractFingerprint(inp);
      const current = String(inp.value || "").trim().toLowerCase();

      const isKnownLinkField =
        fp.includes("linkedin") ||
        fp.includes("google scholar") ||
        fp.includes("github") ||
        fp.includes("portfolio") ||
        fp.includes("personal website") ||
        fp.includes("github/portfolio") ||
        fp.includes("github portfolio");

      if (current && !isKnownLinkField) continue;

      if (fp.includes("github/portfolio") || fp.includes("github portfolio")) {
        fillText(inp, p.links?.github || p.links?.portfolio || "");
      } else if (fp.includes("google scholar")) {
        if (p.links?.google_scholar) fillText(inp, p.links.google_scholar);
      } else if (fp.includes("linkedin")) {
        const target = String(p.links?.linkedin || "").trim();
        if (target && !current.includes("linkedin.com")) fillText(inp, target);
      } else if (fp.includes("github")) {
        fillText(inp, p.links?.github || "");
      } else if (fp.includes("portfolio") || fp.includes("personal website")) {
        fillText(inp, p.links?.portfolio || "");
      }
    }
  }

  /* ═══════════════════════════════════════════════════════════════
     DIRECT FALLBACKS: PHONE + PORTFOLIO
     Some forms render labels in wrappers that confuse generic key matching.
  ═══════════════════════════════════════════════════════════════ */
  function fillCriticalDirectInputs(userData) {
    const p = userData.profile || {};
    function localPhoneNumber() {
      const split = String(p.phone_number || "").trim();
      if (split) return split;
      const combined = String(p.phone || "").trim();
      const m = combined.match(/^\s*\+\d{1,4}[\s\-]*(\d{6,15})\s*$/);
      if (m?.[1]) return m[1];
      return combined.replace(/[^0-9]/g, "");
    }
    const phoneValue = localPhoneNumber();
    const portfolioValue =
      p.links?.portfolio || p.links?.github || p.links?.linkedin || "";

    const inputs = Array.from(document.querySelectorAll(
      'input[type="text"],input[type="url"],input[type="search"],input[type="tel"]'
    ));

    for (const inp of inputs) {
      if (inp.value && inp.value.trim() !== "") continue;
      const fp = FM.extractFingerprint(inp);

      if (phoneValue && /(^|\b)(phone|mobile|telephone|whatsapp)(\b|$)/.test(fp)) {
        fillText(inp, phoneValue);
        continue;
      }

      if (portfolioValue && /(portfolio url|portfolio link|personal website|personal site|personal portfolio|portfolio)/.test(fp)) {
        fillText(inp, portfolioValue);
      }
    }
  }

  /* ═══════════════════════════════════════════════════════════════
     WEBSITES "ADD" BUTTON
  ═══════════════════════════════════════════════════════════════ */
  async function fillWebsiteAddSection(userData) {
    const p = userData.profile || {};
    const links = [p.links?.portfolio, p.links?.github].filter(Boolean);
    if (!links.length) return;

    const addBtns = Array.from(document.querySelectorAll("button,a")).filter(btn => {
      const txt = FM.normalize(btn.innerText || "");
      const section = FM.normalize(btn.closest("section,div,fieldset")?.innerText?.slice(0, 100) || "");
      return txt === "add" && section.includes("website");
    });

    for (let i = 0; i < Math.min(links.length, 3); i++) {
      if (addBtns[0]) { addBtns[0].click(); await delay(400); }

      const urlInputs = Array.from(document.querySelectorAll('input[type="url"],input[type="text"]'))
        .filter(inp => {
          const fp = FM.normalize(inp.placeholder + inp.name + inp.id);
          return (fp.includes("url") || fp.includes("http") || fp.includes("website")) && !inp.value;
        });

      if (urlInputs.length) {
        fillText(urlInputs[urlInputs.length - 1], links[i]);
        await delay(200);
      }
    }
  }

  /* ═══════════════════════════════════════════════════════════════
     RESUME NOTICE
  ═══════════════════════════════════════════════════════════════ */
  async function handleResumeFields(userData) {
    const resumeUrl = userData.profile?.resume_url;
    const fileInputs = Array.from(document.querySelectorAll('input[type="file"]'));

    if (!fileInputs.length) return;

    let fetchResult = null;
    let resumeFile = null;

    if (resumeUrl) {
      uiLog("📎 Resume: fetching file…");
      fetchResult = await sendMessageAsync({
        type: "FILLA_FETCH_RESUME",
        resumeUrl,
      });

      if (fetchResult?.success && fetchResult?.base64) {
        const fileName = parseFilename(fetchResult.contentDisposition, resumeUrl, fetchResult.contentType);
        resumeFile = base64ToFile(fetchResult.base64, fetchResult.contentType, fileName);
      }
    }

    // Keka asks a native confirm dialog after resume upload.
    // Auto-accept only that specific prompt during attach, then restore.
    const originalConfirm = window.confirm;
    const autoAcceptPatterns = [
      "overwrite the existing data",
      "data extracted from the uploaded resume",
    ];

    window.confirm = function patchedConfirm(message) {
      const text = String(message || "").toLowerCase();
      if (autoAcceptPatterns.some(p => text.includes(p))) {
        uiLog("✅ Auto-confirmed resume overwrite prompt");
        return true;
      }
      return originalConfirm.call(window, message);
    };

    fileInputs.forEach(f => {
      highlight(f);

      if (resumeFile) {
        try {
          const dt = new DataTransfer();
          dt.items.add(resumeFile);
          f.files = dt.files;
          fire(f);
          const zone = f.closest("div") || f.parentElement;
          clearResumeErrorText(zone);
          uiLog(`✅ Resume attached: ${resumeFile.name}`);
        } catch (err) {
          uiLog(`⚠️ Resume attach failed: ${err?.message || "unknown error"}`);
        }
      }

      const zone = f.closest("div") || f.parentElement;
      if (zone) {
        let hint = zone.querySelector(".filla-resume-hint");
        if (!hint) {
          hint = document.createElement("div");
          hint.className = "filla-resume-hint";
          zone.appendChild(hint);
        }

        if (resumeFile) {
          hint.innerHTML = `✅ <strong>Filla:</strong> Resume attached automatically (${resumeFile.name}).`;
        } else {
          const reason = fetchResult?.error ? `<br><small>${fetchResult.error}</small>` : "";
          hint.innerHTML = `📎 <strong>Filla:</strong> Upload resume manually.${resumeUrl
            ? `<br><a href="${resumeUrl}" target="_blank">Open your saved resume ↗</a>${reason}`
            : ""
            }`;
        }
      }
    });

    window.confirm = originalConfirm;

    if (!resumeFile) {
      uiLog("📎 Resume: auto-attach unavailable, manual upload needed");
    }
  }

  /* ═══════════════════════════════════════════════════════════════
     MAIN PIPELINE
  ═══════════════════════════════════════════════════════════════ */
  async function startAutofillPipeline(userData) {
    _logLines = [];
    _complexPromptSeen = false;
    removeFloatingLogo();
    hideComplexLoader();
    console.log("[Filla v4] 🚀 Pipeline start");
    showUI("Scanning form…");
    await delay(200);

    // 1. All standard fields
    const fields = Array.from(document.querySelectorAll(
      'input:not([type="radio"]):not([type="hidden"]):not([type="file"]), textarea, select'
    ));

    showUI("Filling fields…", `0 / ${fields.length}`);
    for (let i = 0; i < fields.length; i++) {
      showUI("Filling fields…", `${i + 1} / ${fields.length}`);
      await delay(60);
      await processField(fields[i], userData);
    }

    // 2. Radio groups
    showUI("Filling radio buttons…");
    await delay(100);
    processRadioGroups(userData);

    // 3. Currently-working checkboxes
    fillCurrentlyWorkingCheckboxes(userData);

    // 4. ARIA custom dropdowns
    showUI("Filling custom dropdowns…");
    await processAriaDropdowns(userData);

    // 5. Social / website links (direct inputs)
    await fillSocialAndWebsiteLinks(userData);

    // 5b. Critical direct fallback for stubborn forms
    fillCriticalDirectInputs(userData);

    // 6. Websites "Add" section
    await fillWebsiteAddSection(userData);

    // 7. Resume
    await handleResumeFields(userData);

    // 8. Unknown/unmapped fields AI stubs
    injectUnknownAIButtons(userData);

    if (_complexPromptSeen) {
      uiLog("🧠 Complex question left for AI/manual completion");
    }

    showUI("✅ Done!", `${fields.length} fields processed`);
    uiLog("Pipeline complete");
    hideUI();
    hideComplexLoader();
    applyFloatingLogoForPage();

    console.log("[Filla v4] ✅ Pipeline complete");
  }

  /* ═══════════════════════════════════════════════════════════════
     MESSAGE HANDLER
  ═══════════════════════════════════════════════════════════════ */
  function handleMessage(message, _sender, sendResponse) {
    if (message.type !== "FILLA_AUTOFILL") return;
    const { userData } = message;
    if (!userData) {
      sendResponse({ success: false, error: "No userData" });
      return true;
    }
    startAutofillPipeline(userData)
      .then(() => sendResponse({ success: true }))
      .catch(err => {
        console.error("[Filla v4] ❌", err);
        sendResponse({ success: false, error: err.message });
      });
    return true;
  }

  chrome.runtime.onMessage.addListener(handleMessage);
  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", setupFloatingLogoWatcher, { once: true });
  } else {
    setupFloatingLogoWatcher();
  }
  console.log("[Filla v4] 🟢 Content script loaded");
})();
